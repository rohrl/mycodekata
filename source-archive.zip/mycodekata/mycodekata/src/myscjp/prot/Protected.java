package myscjp.prot;

public class Protected {

	protected int x = 1;
}



