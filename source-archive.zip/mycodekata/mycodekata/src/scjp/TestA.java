package scjp;

public interface TestA {

	public static int z =0;
	
}
