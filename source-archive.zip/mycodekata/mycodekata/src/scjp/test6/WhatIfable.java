package scjp.test6;

public interface WhatIfable {

	public String whatThe();
	
}
