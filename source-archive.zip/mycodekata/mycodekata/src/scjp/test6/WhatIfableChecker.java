package scjp.test6;

public class WhatIfableChecker {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println(new scjp.Test6().getWhat().whatThe());
	}

}
