package concurrency;

public class BlockingQueueToDo {

}
