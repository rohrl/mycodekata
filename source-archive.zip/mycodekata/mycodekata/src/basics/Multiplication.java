package basics;

public class Multiplication {

}
