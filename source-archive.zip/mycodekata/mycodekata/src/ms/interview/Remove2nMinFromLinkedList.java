package ms.interview;

public class Remove2nMinFromLinkedList {

}
