package scjp.notjavac.test3;

public class Duck {

	protected int nFeathers = 456;
	
}
