package scjp;

import com.sun.org.omg.SendingContext.CodeBase;

import scjp.test6.WhatIfable;

public class Test6 {

	

	public void testConstructors() {
		new Extending();
	}

	private class WhatIf implements WhatIfable {

		public String whatThe() {
			return "whatThePrivate!";
		}
	}

	public WhatIfable getWhat() {
		return new WhatIf();
	}

	private Comparable<CodeBase> comparable = new Comparable<CodeBase>() {

		public int compareTo(CodeBase arg0) {
			return 0;
		}

	};

	class Base {

		public Base() {
			System.out
					.println("default constructor for base class is invoked before subclasses' constructors");
		}
	}

	class Extending extends Base {

		public Extending() {
			System.out.println("default constructor of extending class");
		}

	}

	class VarArgs {

		void invoking() {
			System.out
					.println("You can invoke a var-arg method with no arguments");
			doItWithArgs();
		}

		void doItWithArgs(String... many) {

		}

	}

}