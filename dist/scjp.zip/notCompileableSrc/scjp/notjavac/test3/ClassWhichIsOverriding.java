package scjp.notjavac.test3;

public class ClassWhichIsOverriding extends PublicClassWithPrivateVariables {

	public void toOverride(){

	}
	
	public void normalMethod(){
		toOverride();
	}
	
}
